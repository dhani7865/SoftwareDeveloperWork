<h1>ABOUT</h1>

<!--- Adding stylesheet --->
<style>
<?php
include 'stylesheet.css';
?>
</style>

<?php

// execute the header script:
require_once "header.php";

echo "This is the 2CWK50, for this assignment we need to add variety of different things. For example, adding client-side and server-side validation, for the set profile and adding calender to allow the user to select a date. First we would need to create a table called posts in the create data file for the social media page. We also have to create social media page which allows users to type in post and submit it to the database. For top marks we had to create api to allow the user to like the different posts and show the 5 recent posts. Another task we  got is, creating admin account, to allow the admin to mute and unmute abusive posts.  <br><br>";

echo "The code quality would also need to good as this will be marked to. We also need to add comments as we add stuff to the site.  <br><br>";

// finish of the HTML for this page:
require_once "footer.php";

?>