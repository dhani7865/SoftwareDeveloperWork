<?php
// default values for Xampp:
// dbhost equal to localhost
$dbhost  = 'localhost';
// dbuser equal to root
$dbuser  = 'root';
// dbpass equal to empty string
$dbpass  = '';
// dbname equal to skeleton
$dbname  = 'skeleton';
?>