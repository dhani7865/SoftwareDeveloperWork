<?php

// finish outputting the HTML for this page:
echo <<<_END
<br>
&copy;6G5Z2107
</body>
</html>
_END;
?>