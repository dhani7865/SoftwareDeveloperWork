<!--- Adding stylesheet --->
<style>
<?php
include 'stylesheet.css';
?>
</style>

<h1>LIBRARIES FOR VIDEO SHARING</h1>


<?php // open php tag


// You should use client-side code (i.e., HTML5/JavaScript/jQuery) to help you organise and present your analysis 
// For example, using tables, bullet point lists, images, hyperlinking to relevant materials, etc.


// execute the header script:
require_once "header.php";
// execute the header script:
require_once "header.php";
// this will call the helper.php file
include_once "helper.php";

// if logged in skeleton
if (!isset($_SESSION['loggedInSkeleton'])) {
    // user isn't logged in, display a message saying they must be:
    echo "You must be logged in to view this page.<br>";
} // close if statment
?>ightweight</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free plugins available for popular platforms</li>
        <li>can be easily changed using HTML and CSS</li>
        <li>Another advantage is; it gives a getting started guide, to make it alot eaier for users</li>
        <li>The file  in minutes. The main difference with Popcorn.js is, it only requires 7 lines of JavaScript to get it done, which would save time from writing loads of line over and over again. Jplayer requires no licensing restrictions. Both of these libraries have wide range of support available. Another difference is JPlayer is a JQuery plugin. </p>

    <!--- the advantages --->
    <h2> Advantages</h2>        
    <ul>
        <li>It is easy to get started with.</li>
        <li>Lightweight</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free plugins available for popular platforms</li>
        <li>can be easily changed using HTML and CSS</li>
        <li>Another advantage is; it gives a getting started guide, to make it alot eaier for users</li>
        <li>The file  in minutes. The main difference with Popcorn.js is, it only requires 7 lines of JavaScript to get it done, which would save time from writing loads of line over and over again. Jplayer requires no licensing restrictions. Both of these libraries have wide range of support available. Another difference is JPlayer is a JQuery plugin. </p>

    <!--- the advantages --->
    <h2> Advantages</h2>        
    <ul>
        <li>It is easy to get started with.</li>
        <li>Lightweight</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free plugins available for popular platforms</li>
        <li>can be easily changed using HTML and CSS</li>
        <li>Another advantage is; it gives a getting started guide, to make it alot eaier for users</li>
        <li>The file  in minutes. The main difference with Popcorn.js is, it only requires 7 lines of JavaScript to get it done, which would save time from writing loads of line over and over again. Jplayer requires no licensing restrictions. Both of these libraries have wide range of support available. Another difference is JPlayer is a JQuery plugin. </p>

    <!--- the advantages --->
    <h2> Advantages</h2>        
    <ul>
        <li>It is easy to get started with.</li>
        <li>Lightweight</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free plugins available for popular platforms</li>
        <li>can be easily changed using HTML and CSS</li>
        <li>Another advantage is; it gives a getting started guide, to make it alot eaier for users</li>
        <li>The file  in minutes. The main difference with Popcorn.js is, it only requires 7 lines of JavaScript to get it done, which would save time from writing loads of line over and over again. Jplayer requires no licensing restrictions. Both of these libraries have wide range of support available. Another difference is JPlayer is a JQuery plugin. </p>

    <!--- the advantages --->
    <h2> Advantages</h2>        
    <ul>
        <li>It is easy to get started with.</li>
        <li>Lightweight</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free plugins available for popular platforms</li>
        <li>can be easily changed using HTML and CSS</li>
        <li>Another advantage is; it gives a getting started guide, to make it alot eaier for users</li>
        <li>The file is only 14KB which means it won't take up much storage will be taken up.</li>
    </ul>

    <!--- 2nd library --->
    <h1>VIDEO.JS</h1>
        <!--- Creating p tags for all the data --->
        <p>The second javascript library which can be used is, Video.js for video sharing. Video.js is a web video player. It would support HTML5 and Flash videos, as well as YouTube; through different plugins. I like the look of video.js and what it can do. </p>
        <p> This project was started in mid 2010 November 17th. The player is now used on 200,000 web pages accross the world. </p>
        <p>API documents are automatically connected from the codebase and give specific details about different functions, properties etc. </p>
        <p>This is another library which i like the look of as it also supports video sharing. Different pllugins would make it possible to adapt your player. </p>
        <p> There are two types of documentation: Guides and API. Documentations are useful as it would make it a lot easier for other users. For example, it would give a setup guide, on how to use the library. Documentation would also be useful for beginners. It has different plugins. </p>
        <p> This library is also regularly maintained and it will continue to be maintained. It regularly has new updates to make the library a lot faster and easier for users.     </p>
        <p>Video.js will then read the tag and make it work in all browsers, not just the  ones that support HTML5. It has a set of main plugins that would offer support for different additional video fomats. </p>
        <p>Older versions and newer verions will support video.js. Video.js is a free and open ource, which can be used on different browsers. </p>
        <p>JQuery is intigrated with other libraries, such as, Video.js. </p>
    
    <!--- the advantages --->
    <h2>Advantages</h2        
    
    <ul>
        <li>It supports video playback on desktops and mobile devices, which would make it a lot easier for users</li>
        <li>Also free and open source; can be downloaded on any source</li>
        <li>Free and open source, no licensing required</li>
        <li>Can be downloaded on any source</li>
    </ul>

    
    <!--- third library --->
    <h1>POPCORN.JS</h1>
        <!--- Creating p tags for all the data --->
        <p>Popcorn.js is a JavaScript library which allows video, audio and other media to control and be controlled by elements of a webpage. It is an HTML5 media framework written in JavaScript for filmmakers and web developers. </p>
        <p>Popcorn.js is brought by Mozilla (firefox). Popcorn.js is an open source JavaScript library for HTML5 media developers. It can be ued on open web and can be dwnloaded on multiple platforms </p>
        <p>I like the look of this library, for example, t allows web developers, filmmakers, artists, designers and others to easily create timeline based web designs. Also, Anything you can do on the web can be turned into a Popcorn.js. </p>
        <p>Popcorn.js is no longer maintained by mozila. It is likely to continue. For example, with the old versions they are most likelly to get bugs that newer versions. Popcorn.js also allows developers/users  to easily create timeline web productions. </p>
        <p>The example shows 3 video source elements: .mp4, .ogv, and .webm. This is done to ensure that the video will play across all major browsers. Also older versions would support it, but the problems wouldn't be fixed, as they will only be fixed on newer versions. </p>
        <p>Popcorn.js is well documented. for example, if someone needs guide how to set it up there would be a full documentation guide on how to do it. There are also other documentations availanle such as, how to use it. </p>
        <p>There is support available if needed. The support which is available are, If there are any problems you can contact them or fill out a form online and you would need to provide the problem.     </p>
        <p> It is free and open source, which can be used on multiple commercial projects. The API documentation has resources to create a first project, add some extra data to media with a plugin, and understand how to write some simple Popcorn.js code. This is useful as it would make it a lot easier for the developer because it would show you how to write simple code. This is mainly supported for Mozilla. The only problem it has are some errors wouldn't be fixed on older versions and can only be fixed on new versions. </p>
        <p>Comparing Popcorn.js and Video.js: Popcorn.js is a similar lobrary to video.js. For example, the similaraties are, they both support HTML5 and Flash video, YouTube and Vimeo. The only difference with Video.js is it would only work through plugins. Another similarity is, they both can be downloaded on multiple platforms. Another difference between these libraries are; with video.js it uses Jquery plugin which is intigrated with other libraries.</p>
    <!--- the advantages --->
    <h2>Advantages</h2>        
    <ul>
        <li>Popcorn.js can be used with various other types of media other than HTML5 video and audio. For example, this means that it can be used with YouTube, Vimeo, and SoundCloud.</li>
        <li>It is also free and is available under the MIT license.</li>
        <li>Another advantage is, it would give a start up guide on how to use it especially for beginners.</li>
        <li>It is very easy to create timeline based web productions.</li>
        <li>Overall, it is easy to use for users.</li>
    </ul>
        
    <!---conclusion - overall my opinion --->
    <h1>CONCLUSION</h1>
    <!--- Creating p tag for my overall opinion --->
        <p> Overall, in my opinion I think Popcorn.js is usefull library. However, it allows various other types of media other than HTML5 video and audio. Furthermore, this means that it can be used with YouTube, Vimeo, and SoundCloud. It is also free and can be downloaded on multiple platforms. It would also give a start up guide on how to use it. This would be a benefit for beginners. It has 3 video source elements such as; .mp4, .ogv, and .webm. This would be done to ensure that the video will play across all browsers. The main similarity between all these libraries are, they are all free and open source libraries which can be used on multiple platforms/browsers. The 3 libraries which i have discussed/recommended; have their own advantages. </p>


<!--- finish off the HTML for this page: --->
<!---require_once "footer.php";
</html> <!--- Close html tag --->
</body> <!--- Close body tag --->